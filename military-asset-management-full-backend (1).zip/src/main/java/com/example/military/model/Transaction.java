package com.example.military.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String type;
    private int quantity;
    private LocalDateTime timestamp;

    @ManyToOne
    private Asset asset;

    @ManyToOne
    private Base sourceBase;

    @ManyToOne
    private Base destinationBase;

    // Getters and Setters
}