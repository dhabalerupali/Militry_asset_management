package com.example.military.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Assignment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String personnelName;
    private int quantity;
    private LocalDateTime assignedAt;

    @ManyToOne
    private Asset asset;

    // Getters and Setters
}